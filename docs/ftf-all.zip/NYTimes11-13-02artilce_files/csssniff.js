<!--
  if (navigator.platform == "MacPPC") {
    if (navigator.appName == "Netscape"){
      if(parseFloat(window.navigator.appVersion) >= 5.0){
        //document.write("<link rel='stylesheet' href='/css/sft1_mac.css' type='text/css'>")
	document.write("<link rel='stylesheet' href='/css/sft1.css' type='text/css'>")
      }
      else{
        document.write("<link rel='stylesheet' href='/css/sft1_mac.css' type='text/css'>")
      }
    }
    else {
      document.write("<link rel='stylesheet' href='/css/sft1.css' type='text/css'>")}
    }
  else {
    document.write("<link rel='stylesheet' href='/css/sft1.css' type='text/css'>")
  }
// -->

